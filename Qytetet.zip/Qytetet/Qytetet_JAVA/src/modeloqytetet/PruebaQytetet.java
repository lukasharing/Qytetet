package modeloqytetet;
public class PruebaQytetet {
    private static Qytetet juego = new Qytetet();
    public static void main (String [ ] args){
        System.out.println(juego.toString());
    }
}
