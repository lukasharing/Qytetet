package modeloqytetet;

public class Dado {
    public static int tirar(){
        return ((int)(Math.random() * 6) + 1);
    }
}
