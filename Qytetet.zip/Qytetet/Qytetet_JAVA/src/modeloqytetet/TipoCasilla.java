package modeloqytetet;

public enum TipoCasilla {
    SALIDA,
    SORPRESA,
    CARCEL,
    JUEZ,
    IMPUESTO,
    PARKING
}
