package modeloqytetet;

public enum TipoSorpresa {
    PAGARCOBRAR,
    IRACASILLA,
    PORCASAHOTEL,
    PORJUGADOR,
    SALIRCARCEL,
    CONVERTIRME
}
