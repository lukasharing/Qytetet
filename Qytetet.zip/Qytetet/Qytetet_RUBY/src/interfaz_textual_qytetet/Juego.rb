#encoding: utf-8
require_relative 'ControladorQytetet'
class Juego
  juego = InterfazTextualQytetet::ControladorQytetet.new
  juego.inicializacion_juego
end