module TipoSorpresa
  PAGARCOBRAR   = :PagarCobrar
  IRACASILLA    = :IrACasilla
  PORCASAHOTEL  = :PorCasaHotel
  PORJUGADOR    = :PorJugador
  SALIRCARCEL   = :SalirCarcel
end