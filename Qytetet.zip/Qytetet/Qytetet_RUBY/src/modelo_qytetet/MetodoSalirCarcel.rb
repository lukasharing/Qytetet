#encoding: utf-8
module ModeloQytetet
  class MetodoSalirCarcel
    TIRANDODADO     = :Tirandodado
    PAGANDOLIBERTAD = :PagandoLibertad
  end
end