module TipoCasilla
  SALIDA    = :Salida
  CALLE     = :Calle
  CARCEL    = :Carcel
  JUEZ      = :Juez
  SORPRESA  = :Sorpresa
  IMPUESTO  = :Impuesto
  PARKING   = :Parking
end