module SalirCarcel
  TIRANDODADO     = :Tirandodado
  PAGANDOLIBERTAD = :PagandoLibertad
end