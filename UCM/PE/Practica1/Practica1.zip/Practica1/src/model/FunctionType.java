package model;

public enum FunctionType {
	MAXIMIZE, MINIMIZE
}
