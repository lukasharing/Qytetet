package model;

import javax.swing.UnsupportedLookAndFeelException;

import gui.Panel;

public class Main {

	public static void main(String[] args) throws ClassNotFoundException, InstantiationException, IllegalAccessException, UnsupportedLookAndFeelException {
		System.out.println("Algoritmo Gen�tico.");
		
		new Panel();
	}
}
