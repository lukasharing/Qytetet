package model;

public enum CrossType {
	MONOPOINT, MULTIPOINT, UNIFORM
}
