package model;

public enum MutationType {
	RANDOM, UNIFORM, NONUNIFORM
}
