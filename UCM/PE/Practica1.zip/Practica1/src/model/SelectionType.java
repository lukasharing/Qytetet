package model;

public enum SelectionType {
	ROULETTE, DETE_TOURNAMENT, PRB_TOURNAMENT
};
