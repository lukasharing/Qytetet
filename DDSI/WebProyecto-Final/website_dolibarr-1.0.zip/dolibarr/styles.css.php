@import url('https://fonts.googleapis.com/css?family=Roboto&display=swap');

body, html{
    width: 100%;
    height: 100%;
}

body{
    padding: 0;
    margin: 0;
    font-family: 'Roboto', sans-serif;
    display: flex;
}

header {
    width: 200px;
}

header > nav{
    margin: 50px 10px;
}

header > nav > figure{
    margin: 0 0 10px 0;
    display: flex;
    align-items: center;
    justify-content: center;
}

header > nav > ul {
    margin: 0;
    padding: 0;
    list-style: none;
}

header > nav > ul > li{
    margin-bottom: 10px;
}

header > nav > ul > li > a{
    transition: 0.5s all;
    -webkit-transition: 0.5s all;
    display: block;
    padding: 10px 20px;
    background-color: #0cc97b;
    text-decoration: none;
    text-transform: uppercase;
    color: #333;
}


header > nav > ul > li > a:hover{
    background-color: #228e62;
}

main {
    flex: 1;
    display: flex;
    align-items: center;
    justify-content: center;
}

main > nav {
    width: 80%;
}

main > nav > ul{
    margin: 0;
    padding: 0;
    list-style-type: none;
    display: flex;
    justify-content: space-between;
    flex-basis: 50%;
    flex-wrap: wrap;
}

main > nav > ul > li{
    margin-bottom: 20px;
    width: 180px;
    height: 180px;
    padding: 10px;
    display: flex;
}

main > nav > ul > li > a{
    transition: 0.5s all;
    -webkit-transition: 0.5s all;
    flex: 1;
    display: flex;
    align-items: center;
    justify-content: center;
    background-color: #fbacf8;
    color: #111;
    text-transform: uppercase;
    text-decoration: none;
}

main > nav > ul > li > a:hover{
    background-color: #c69ec4;
}

main > nav > ul > li > a > figure{
    width: 90px;
    text-align: center;
}

main > nav > ul > li > a > figure > figcaption{
    margin-top: 15px;
}