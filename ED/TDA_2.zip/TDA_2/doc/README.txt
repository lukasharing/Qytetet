This project is _only_ made by Lukas Haring García, from the University of Granada.
Known bugs:
  1. Cleanning ASCII string can confuse the tag algorithm, some tags won't appear or will appear as
  composite ones.
  2. The bug number (1.) may also affect to the search algorithm.

!!!!!!IMPORTANTE!!!! Como trabajo con Window, mis .h contenían ya la información de los cpp de cada uno de los include, pero como no tengo Ubuntu, el makefile no funciona
