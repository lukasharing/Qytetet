package model;

import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.stream.DoubleStream;

public class GeneticAlgorithm<T> {
	private ArrayList<T> chromosomes; //Population
	private T best_chromosome;
	
	private Class<T> class_type;
	
	// Function
	private Function function = null;
	
	// Child and parents
	private int initial_population = 0;
	private int total_generations = 0;
	private double gene_precision = 0.0;
	
	// Probabilities
	private double crossing_prob = 0.0;
	private double mutation_prob = 0.0;
	
	// Constructor
	public GeneticAlgorithm(Class<T> class_type, int population, int generations, double crossoverProbability, double mutationProbability, double precision, Function evaluationFunction){
		this.class_type = class_type;
		this.initial_population = population;
		this.total_generations = generations;
		this.gene_precision = precision;
		
		this.crossing_prob = crossoverProbability;
		this.mutation_prob = mutationProbability;
		this.function = evaluationFunction;
		
		chromosomes = new ArrayList<>();
		
		try{
			this.createInitialPopulation();
		}catch(Exception ex) {
			System.err.println(ex.getMessage());
			System.exit(0); 
		}
	};
	
	public void test() {
		this.selection(SelectionType.ROULETTE, this.evaluation());
		/*for(T chromosme : chromosomes) {
			System.out.println(Arrays.toString(((Chromosome) chromosme).getFenotypes()));
			System.out.println("Mutate");
			((Chromosome)chromosme).randomMutation(this.mutation_prob);
			System.out.println(Arrays.toString(((Chromosome) chromosme).getFenotypes()));
			System.out.println("---------------");
		}*/
	};
	
	// Iterate
	public void run() {
		int currentGeneration = 0;
		
		
		double[] eval_result = this.evaluation();
		
		while(currentGeneration < total_generations) {
			currentGeneration++;
			this.selection(SelectionType.ROULETTE, eval_result);
			this.crossover();
			this.mutation();
			eval_result = this.evaluation();
		}
	};
	
	
	// Init population
	public void createInitialPopulation() throws Exception{
		// Creationf Binary Chromosomes
		if(class_type.getName().contains("BinaryChromosome")) {
		
			for(int i = 0; i < initial_population; ++i) {
				chromosomes.add((T) BinaryChromosome.newBinary(function, gene_precision));
			}
		
		// Creation of Real Chromosomes
		}else if(class_type.getName().contains("RealChromosome")) {
			for(int i = 0; i < initial_population; ++i) {
				//chromosomes.add((T) BinaryChromosome.newBinary(evaluation, gene_precision));
			}
		}
		
	}
	
	// Evaluate Population
	private double[] evaluation(boolean elitism) {
		int size = chromosomes.size();
		double[] eval_results = new double[size];
		for(int i = 0; i < size; ++i) {
			eval_results[0] = function.evaluate(((Chromosome)chromosomes.get(i)).getFenotypes());
		}
		
		double max = Arrays.stream(eval_results).max().getAsDouble();
		
		// Mapeamos minimizacion.
		DoubleStream mapping;
		mapping = Arrays.stream(eval_results).map((e) -> max - e);
		double total_sum = mapping.sum();
		mapping = mapping.map((e) -> e / total_sum);
		
		return mapping.toArray();
	}
	
	private void selection(SelectionType type, double[] evaluations) {
		ArrayList<T> result = new ArrayList<>(initial_population); 
		switch(type){
			case ROULETTE:
				
				
				
			break;
		}
	}
	
	private boolean crossover() {
		return true;
	}
	
	private void mutation() {
		for(T chromosome : chromosomes) {
			((Chromosome) chromosome).randomMutation(mutation_prob);
		}
	};
	
}
