package model;

public enum SelectionType {
	ROULETTE
};
