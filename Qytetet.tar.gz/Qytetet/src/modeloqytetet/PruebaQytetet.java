/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modeloqytetet;
import java.util.ArrayList;

/**
 *
 * @author lukasharing
 * @version 0.0
 * @since 27/09/17
 */
public class PruebaQytetet {
    private static final ArrayList<Sorpresa> mazo = new ArrayList();
    
    public static void main(String[] args) {
        // TODO code application logic here
        inicializarSorpresas();
        for(int i = 0; i < mazo.size(); i++){
            System.out.printf(mazo.get(i).toString() + "\n");
        }
    }
    
    private static void inicializarSorpresas() {
        // Añadimos las cartas de PAGARCOBRAR (x2)
        mazo.add(new Sorpresa("Has ganado la lotería!", +100, TipoSorpresa.PAGARCOBRAR));
        mazo.add(new Sorpresa("Has perdido tu cartera en la calle...", -100, TipoSorpresa.PAGARCOBRAR));
        
        // Añadimos las cartas de IRACASILLA (x3)
        mazo.add(new Sorpresa("Te vas a Paseo del prado", 18, TipoSorpresa.IRACASILLA));
        mazo.add(new Sorpresa("Te trasladan a la salida.", 0, TipoSorpresa.IRACASILLA));
        mazo.add(new Sorpresa("¡A la carcel!", 10, TipoSorpresa.IRACASILLA));
        
        // Añadimos las cartas de PORCASAHOTEL (x2)
        mazo.add(new Sorpresa("Debes cobrar por tus propiedades", 10, TipoSorpresa.PORCASAHOTEL));
        mazo.add(new Sorpresa("Debes pagar por tus propiedades", -10, TipoSorpresa.PORCASAHOTEL));
        
        // Añadimos las cartas de PORJUGADOR (x2)
        mazo.add(new Sorpresa("Recibes de los demás jugadores", 20, TipoSorpresa.PORJUGADOR));
        mazo.add(new Sorpresa("Debes darles a los demás jugadores", -5, TipoSorpresa.PORJUGADOR));
        
        // Añadimos las cartas de SALIRCARCEL (x1)
        mazo.add(new Sorpresa("Hola Mundo", 10, TipoSorpresa.SALIRCARCEL));
    }
    
}
