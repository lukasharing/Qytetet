package modeloqytetet;

/*
 * El precio de edificación debe estar entre 250 y 750€
 * El factor de revalorización de la venta estará entre el 10 y el 20% y puede ser positivo si la
 * vivienda se revaloriza o negativo si se devalúa.
 * El precio base del alquiler debe estar entre 50 y 100€
 * El precio base de la hipoteca debe estar entre 150 y 1000€
 */

public class TituloPropiedad {
    private final   String nombre;
    private boolean hipotecada;
    private int     alquilerBase;
    private float   factorRevalorizacion;
    private int     hipotecaBase;
    private int     precioEdificar;
    /**
     * @param {String}[ Nombre de la propiedad ]
     * @param {int}   [ Valor del alquiler base]
     * @param {float} [ Valor de la revalorización ]
     * @param {float} [ Valor de la hipoteca base ]
     * @param {float} [ Valor de la edificación ]
     * @see {Constructor de creación de las cartas Sorpresas}
    */
    public TituloPropiedad(String _nombre, int _alquilerbase, float _revalorizacion, int _hipotecabase, int _edificacion){
        nombre              = _nombre;
        hipotecada          = false;
        alquilerBase        = _alquilerbase;
        factorRevalorizacion= _revalorizacion;
        hipotecaBase        = _hipotecabase;
        precioEdificar      = _edificacion;
    };
    
    public String getNombre(){ return nombre; };
    
    public boolean getHipotecada(){ return hipotecada; };
    public void setHipotecada(boolean _hipotecada){ hipotecada = _hipotecada; };
    
    public int getAlquilerBase(){ return alquilerBase; };
    public float getFactorRevalorizacion(){ return factorRevalorizacion; };
    public int getHipotecaBase(){ return hipotecaBase; };
    public int getPrecioEdificar(){ return precioEdificar; };

    @Override
    public String toString() {
        return "TituloPropiedad{" + "nombre=" + nombre + ", hipotecada=" + hipotecada + ", alquilerBase=" + alquilerBase + ", factorRevalorizacion=" + factorRevalorizacion + ", hipotecaBase=" + hipotecaBase + ", precioEdificar=" + precioEdificar + '}';
    }
}
