package modeloqytetet;

public class Casilla {
    private final int numeroCasilla;
    private final int coste;
    private int numHoteles;
    private int numCasas;
    private final TipoCasilla tipo;
    private final TituloPropiedad titulo;

    
    Casilla(TipoCasilla _tipo, int _numero){
        numeroCasilla = _numero;
        setHoteles(0);
        setCasas(0);
    };
    
    
    public int getNumeroCasilla(){ return numeroCasilla; }
    public int getCoste(){ return coste; }
    public TipoCasilla getTipo(){ return tipo; }
    public TituloPropiedad getTitulo(){ return titulo; }
    
    public int getHoteles(){ return numHoteles; }
    private void setHoteles(int a){ numHoteles = a; };
    
    public int getCasas(){ return numCasas; }
    private void setCasas(int a){ numCasas = a; };

    @Override
    public String toString() {
        return "Casilla{" + "numeroCasilla=" + numeroCasilla + ", coste=" + coste + ", numHoteles=" + numHoteles + ", numCasas=" + numCasas + ", tipo=" + tipo + ", titulo=" + titulo + '}';
    }
    
    
}
