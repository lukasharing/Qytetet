package interfazTextualQytetet;

public class Juego {
	private static ControladorQytetet juego = new ControladorQytetet();
	public static void main(String[] args) {
		juego.inicializacionJuego();
    }
}
