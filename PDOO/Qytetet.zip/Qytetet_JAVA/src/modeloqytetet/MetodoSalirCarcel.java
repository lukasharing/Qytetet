package modeloqytetet;
public enum MetodoSalirCarcel {
    TIRANDODADO,
    PAGANDOLIBERTAD
}
