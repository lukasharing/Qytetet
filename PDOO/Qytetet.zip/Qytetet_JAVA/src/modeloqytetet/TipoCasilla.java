package modeloqytetet;

public enum TipoCasilla {
    SALIDA,
    CALLE,
    SORPRESA,
    CARCEL,
    JUEZ,
    IMPUESTO,
    PARKING
}
