package modeloqytetet;

public class Casilla {
    private final int numeroCasilla;
    private final int coste;
    private int numHoteles;
    private int numCasas;
    private final TipoCasilla tipo;
    private TituloPropiedad titulo;

    
    Casilla(TipoCasilla tipo, int numero){
        this.numeroCasilla   = numero;
        this.numHoteles      = 0;
        this.numCasas        = 0;
        this.tipo            = tipo;
        this.titulo          = null;
        this.coste           = 0;
    };
    
    Casilla(TituloPropiedad titulo, int numero, int coste){
        this.numeroCasilla   = numero;
        this.numHoteles      = 0;
        this.numCasas        = 0;
        this.tipo            = TipoCasilla.CALLE;
        this.titulo          = titulo;
        this.coste           = coste;
    };
    
    
    public int getNumeroCasilla(){ return numeroCasilla; }
    public int getCoste(){ return coste; }
    public TipoCasilla getTipo(){ return tipo; }
    public TituloPropiedad getTitulo(){ return titulo; }
    
    public int getHoteles(){ return numHoteles; }
    private void setHoteles(int a){ numHoteles = a; };
    
    public int getCasas(){ return numCasas; }
    private void setCasas(int a){ numCasas = a; };

    private void setTituloPropiedad(TituloPropiedad propiedad){ titulo = propiedad; };
    
    @Override
    public String toString() {
        return "Casilla{" + "numeroCasilla=" + numeroCasilla + ", coste=" + coste + ", numHoteles=" + numHoteles + ", numCasas=" + numCasas + ", tipo=" + tipo + ", titulo=" + titulo + '}';
    }
    
    
}
